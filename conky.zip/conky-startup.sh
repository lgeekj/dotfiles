#!/bin/sh

if [ x"${DESKTOP_SESSION##*/}" = x"xfce" ]; then 
   sleep 20s
   killall conky
   cd "$HOME/.conky/MX-Asq/MX-GeekyTowerLogo"
   conky -c "$HOME/.conky/MX-Asq/MX-GeekyTowerLogo/MX-geekytowerLogo" &
   exit 0
fi
if [ x"${DESKTOP_SESSION##*/}" = x"openbox" ]; then 
   sleep 5s
   killall conky
   cd "$HOME/.conky/MX-Asq/MX-GeekyTowerLogo"
   conky -c "$HOME/.conky/MX-Asq/MX-GeekyTowerLogo/MX-geekytowerLogo" &
   exit 0
fi
